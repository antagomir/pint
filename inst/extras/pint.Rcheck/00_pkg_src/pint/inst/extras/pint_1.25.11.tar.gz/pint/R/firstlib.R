.onAttach <- function(lib, pkg)
{
   packageStartupMessage('\npint Copyright (C) 2008-2013 Olli-Pekka Huovilainen and Leo Lahti.\n
This program comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under the FreeBSD license.\n')
}
