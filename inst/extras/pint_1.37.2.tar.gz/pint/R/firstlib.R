#' @importFrom dmt getParams
#' @import mvtnorm
#' @import methods
#' @import graphics
#' @import Matrix
.onAttach <- function(lib, pkg)
{
   packageStartupMessage('\npint Copyright (C) 2008-2019 Olli-Pekka Huovilainen and Leo Lahti. microbiome.github.io.\n')
}

